#  AWS Certified Machine Learning-Specialty (ML-S) Guide

[Interactive Jupyter/Colab book companion](https://noahgift.github.io/aws-ml-guide/) to [AWS Certified Machine Learning-Speciality Video](https://learning.oreilly.com/videos/aws-certified-machine/9780135556597)
