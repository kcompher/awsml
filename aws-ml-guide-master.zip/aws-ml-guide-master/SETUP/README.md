Setup to build out TEMPLATE
