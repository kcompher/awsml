#  AWS Certified Machine Learning-Specialty (ML-S) Guide

![awsmlbook](https://user-images.githubusercontent.com/58792/54616901-a4bf0580-4a1d-11e9-8d46-a9d982b96f07.png)

[Interactive Jupyter/Colab book companion](https://noahgift.github.io/aws-ml-guide/) to [AWS Certified Machine Learning-Speciality Video](https://learning.oreilly.com/videos/aws-certified-machine/9780135556597)
